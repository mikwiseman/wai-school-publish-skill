const grid = document.querySelector("#choice-grid");
const resultTitle = document.querySelector("#result-title");
const resultCopy = document.querySelector("#result-copy");
const impact = document.querySelector("#impact");
const meter = document.querySelector("#meter");
const startBtn = document.querySelector("#start");
const remixBtn = document.querySelector("#remix");
const previewCards = [...document.querySelectorAll(".preview-card")];

let options = [];
let selectedIndex = -1;
let previewIndex = 0;

async function loadOptions() {
  const response = await fetch("./data/options.json");
  if (!response.ok) throw new Error("options load failed");
  return response.json();
}

function renderOptions() {
  grid.innerHTML = "";
  options.forEach((option, index) => {
    const card = document.createElement("button");
    card.type = "button";
    card.className = "choice-card";
    card.innerHTML = `
      <span>${String(index + 1).padStart(2, "0")}</span>
      <h3>${option.title}</h3>
      <p>${option.description}</p>
    `;
    card.addEventListener("click", () => selectOption(index));
    grid.append(card);
  });
}

function selectOption(index) {
  selectedIndex = index;
  const option = options[index];
  document.querySelectorAll(".choice-card").forEach((card, cardIndex) => {
    card.classList.toggle("selected", cardIndex === index);
  });
  resultTitle.textContent = option.resultTitle;
  resultCopy.textContent = option.resultCopy;
  animateImpact(option.impact);
  document.querySelector("#result")?.scrollIntoView({ behavior: "smooth", block: "center" });
}

function animateImpact(target) {
  const from = Number(impact.textContent || 0);
  const started = performance.now();
  const duration = 520;
  function tick(now) {
    const t = Math.min(1, (now - started) / duration);
    const eased = 1 - Math.pow(1 - t, 3);
    const value = Math.round(from + (target - from) * eased);
    impact.textContent = String(value);
    meter.style.width = `${value}%`;
    if (t < 1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}

function rotatePreview() {
  previewCards.forEach((card, index) => {
    card.classList.toggle("active", index === previewIndex);
  });
  previewIndex = (previewIndex + 1) % previewCards.length;
}

function remix() {
  if (!options.length) return;
  const next = selectedIndex < 0 ? 0 : (selectedIndex + 1) % options.length;
  selectOption(next);
}

startBtn.addEventListener("click", () => {
  document.querySelector("#choices")?.scrollIntoView({ behavior: "smooth" });
  if (selectedIndex < 0 && options[0]) selectOption(0);
});
remixBtn.addEventListener("click", remix);

loadOptions()
  .then((data) => {
    options = data.options;
    renderOptions();
    setInterval(rotatePreview, 1800);
  })
  .catch(() => {
    grid.innerHTML = '<p class="lead">Could not load data/options.json.</p>';
  });
