Use this folder for local images, icons, sounds, fonts, and generated media.
Keep every path relative, for example ./assets/hero.webp.
