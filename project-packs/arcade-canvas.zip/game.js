const canvas = document.querySelector("#game");
const ctx = canvas.getContext("2d");
const titleEl = document.querySelector("#title");
const keysEl = document.querySelector("#keys");
const keysTotalEl = document.querySelector("#keys-total");
const energyEl = document.querySelector("#energy");
const messageEl = document.querySelector("#message");
const restartBtn = document.querySelector("#restart");

const W = 1280;
const H = 720;
const keys = new Set();
const pointer = { active: false, x: W / 2, y: H / 2 };
let audio;
let level;
let player;
let cores;
let particles;
let drones;
let state;
let lastTime = 0;
let shake = 0;

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function circleRectHit(circle, rect) {
  const x = clamp(circle.x, rect.x, rect.x + rect.w);
  const y = clamp(circle.y, rect.y, rect.y + rect.h);
  const dx = circle.x - x;
  const dy = circle.y - y;
  return dx * dx + dy * dy < circle.r * circle.r;
}

function makeAudio() {
  if (audio) return audio;
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) return null;
  audio = new AudioContextClass();
  return audio;
}

function blip(freq, duration = 0.08, gain = 0.04) {
  const ac = makeAudio();
  if (!ac) return;
  if (ac.state === "suspended") ac.resume();
  const osc = ac.createOscillator();
  const amp = ac.createGain();
  osc.frequency.value = freq;
  osc.type = "triangle";
  amp.gain.setValueAtTime(gain, ac.currentTime);
  amp.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + duration);
  osc.connect(amp).connect(ac.destination);
  osc.start();
  osc.stop(ac.currentTime + duration);
}

async function loadLevel() {
  const response = await fetch("./levels/one.json");
  if (!response.ok) throw new Error("level load failed");
  return response.json();
}

function burst(x, y, color, count = 16) {
  for (let i = 0; i < count; i += 1) {
    const angle = Math.random() * Math.PI * 2;
    const speed = 70 + Math.random() * 260;
    particles.push({
      x,
      y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      life: 0.45 + Math.random() * 0.5,
      max: 0.9,
      color,
    });
  }
}

function reset() {
  player = { x: level.start.x, y: level.start.y, r: 18, vx: 0, vy: 0, energy: 100 };
  cores = level.cores.map((core) => ({ ...core, taken: false, pulse: Math.random() * 9 }));
  drones = level.drones.map((drone) => ({ ...drone, t: Math.random() * 9 }));
  particles = [];
  state = "playing";
  shake = 0;
  updateHud();
  messageEl.textContent = level.brief;
}

function updateHud() {
  const taken = cores.filter((core) => core.taken).length;
  titleEl.textContent = level.title;
  keysEl.textContent = String(taken);
  keysTotalEl.textContent = String(cores.length);
  energyEl.textContent = String(Math.max(0, Math.round(player.energy)));
}

function inputVector() {
  let x = 0;
  let y = 0;
  if (keys.has("ArrowLeft") || keys.has("a")) x -= 1;
  if (keys.has("ArrowRight") || keys.has("d")) x += 1;
  if (keys.has("ArrowUp") || keys.has("w")) y -= 1;
  if (keys.has("ArrowDown") || keys.has("s")) y += 1;
  if (pointer.active) {
    x += clamp((pointer.x - player.x) / 120, -1, 1);
    y += clamp((pointer.y - player.y) / 120, -1, 1);
  }
  const mag = Math.hypot(x, y) || 1;
  return { x: x / mag, y: y / mag };
}

function movePlayer(dt) {
  const input = inputVector();
  const accel = 900;
  player.vx += input.x * accel * dt;
  player.vy += input.y * accel * dt;
  player.vx *= 0.88;
  player.vy *= 0.88;

  const next = {
    x: clamp(player.x + player.vx * dt, player.r, W - player.r),
    y: clamp(player.y + player.vy * dt, player.r, H - player.r),
    r: player.r,
  };

  for (const wall of level.walls) {
    if (circleRectHit(next, wall)) {
      next.x = player.x;
      next.y = player.y;
      player.vx *= -0.25;
      player.vy *= -0.25;
      shake = 8;
    }
  }
  player.x = next.x;
  player.y = next.y;
}

function update(dt) {
  if (state !== "playing") {
    particles.forEach((p) => {
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.life -= dt;
    });
    particles = particles.filter((p) => p.life > 0);
    return;
  }

  movePlayer(dt);
  shake = Math.max(0, shake - 34 * dt);

  for (const core of cores) {
    core.pulse += dt;
    if (!core.taken && Math.hypot(player.x - core.x, player.y - core.y) < player.r + 15) {
      core.taken = true;
      burst(core.x, core.y, "#ffe66d", 22);
      blip(620 + cores.filter((c) => c.taken).length * 80);
      messageEl.textContent = "Core captured. The gate is waking up.";
    }
  }

  for (const drone of drones) {
    drone.t += dt;
    const dx = Math.cos(drone.t * drone.speed) * drone.range;
    const dy = Math.sin(drone.t * drone.speed * 0.74) * drone.range * 0.48;
    drone.x = drone.origin.x + dx;
    drone.y = drone.origin.y + dy;
    if (Math.hypot(player.x - drone.x, player.y - drone.y) < player.r + drone.r) {
      player.energy -= 34 * dt;
      shake = 14;
      if (Math.random() < 0.4) burst(player.x, player.y, "#ff4fb8", 2);
      if (player.energy <= 0) {
        state = "lost";
        messageEl.textContent = "Energy empty. Change the route and try again.";
        burst(player.x, player.y, "#ff4fb8", 34);
        blip(160, 0.22, 0.07);
      }
    }
  }

  const allCores = cores.every((core) => core.taken);
  if (allCores && Math.hypot(player.x - level.gate.x, player.y - level.gate.y) < player.r + level.gate.r) {
    state = "won";
    messageEl.textContent = "Gate online. Add a new level, boss, or final scene next.";
    burst(level.gate.x, level.gate.y, "#43d9ff", 70);
    blip(880, 0.3, 0.08);
  }

  particles.forEach((p) => {
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vx *= 0.96;
    p.vy *= 0.96;
    p.life -= dt;
  });
  particles = particles.filter((p) => p.life > 0);
  updateHud();
}

function drawBackground(time) {
  const gradient = ctx.createLinearGradient(0, 0, W, H);
  gradient.addColorStop(0, "#08111f");
  gradient.addColorStop(0.5, "#11193a");
  gradient.addColorStop(1, "#090b14");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, W, H);

  ctx.save();
  ctx.globalAlpha = 0.18;
  ctx.strokeStyle = "#43d9ff";
  ctx.lineWidth = 1;
  for (let x = -80; x < W + 80; x += 64) {
    ctx.beginPath();
    ctx.moveTo(x + Math.sin(time * 0.001 + x) * 12, 0);
    ctx.lineTo(x - 190, H);
    ctx.stroke();
  }
  ctx.restore();
}

function drawGlowCircle(x, y, r, color, alpha = 1) {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r * 3.2);
  g.addColorStop(0, color);
  g.addColorStop(0.32, color + "99");
  g.addColorStop(1, color + "00");
  ctx.globalAlpha = alpha;
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y, r * 3.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;
}

function draw(time) {
  ctx.save();
  ctx.clearRect(0, 0, W, H);
  if (shake) ctx.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake);
  drawBackground(time);

  for (const wall of level.walls) {
    ctx.fillStyle = "rgba(255,255,255,0.08)";
    ctx.strokeStyle = "rgba(67,217,255,0.35)";
    ctx.lineWidth = 2;
    ctx.fillRect(wall.x, wall.y, wall.w, wall.h);
    ctx.strokeRect(wall.x, wall.y, wall.w, wall.h);
  }

  const gateOpen = cores.every((core) => core.taken);
  drawGlowCircle(level.gate.x, level.gate.y, level.gate.r, gateOpen ? "#43d9ff" : "#62708f", gateOpen ? 0.9 : 0.35);
  ctx.strokeStyle = gateOpen ? "#43d9ff" : "#62708f";
  ctx.lineWidth = 8;
  ctx.beginPath();
  ctx.arc(level.gate.x, level.gate.y, level.gate.r, 0, Math.PI * 2);
  ctx.stroke();

  for (const core of cores) {
    if (core.taken) continue;
    const pulse = Math.sin(core.pulse * 5) * 4;
    drawGlowCircle(core.x, core.y, 14 + pulse, "#ffe66d", 0.8);
    ctx.fillStyle = "#ffe66d";
    ctx.beginPath();
    ctx.arc(core.x, core.y, 9 + pulse * 0.3, 0, Math.PI * 2);
    ctx.fill();
  }

  for (const drone of drones) {
    drawGlowCircle(drone.x, drone.y, drone.r, "#ff4fb8", 0.55);
    ctx.fillStyle = "#ff4fb8";
    ctx.beginPath();
    ctx.arc(drone.x, drone.y, drone.r, 0, Math.PI * 2);
    ctx.fill();
  }

  for (const p of particles) {
    ctx.globalAlpha = clamp(p.life / p.max, 0, 1);
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, 3.5, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;

  drawGlowCircle(player.x, player.y, player.r, "#43d9ff", 0.55);
  ctx.fillStyle = "#f6f2ff";
  ctx.beginPath();
  ctx.arc(player.x, player.y, player.r, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#43d9ff";
  ctx.lineWidth = 4;
  ctx.stroke();

  if (state !== "playing") {
    ctx.fillStyle = "rgba(7, 9, 18, 0.62)";
    ctx.fillRect(0, 0, W, H);
    ctx.textAlign = "center";
    ctx.fillStyle = state === "won" ? "#43d9ff" : "#ff4fb8";
    ctx.font = "900 76px system-ui";
    ctx.fillText(state === "won" ? "GATE ONLINE" : "TRY AGAIN", W / 2, H / 2);
    ctx.fillStyle = "#f6f2ff";
    ctx.font = "600 24px system-ui";
    ctx.fillText("Press Restart or Space", W / 2, H / 2 + 48);
  }
  ctx.restore();
}

function frame(time) {
  const dt = Math.min(0.033, (time - lastTime) / 1000 || 0.016);
  lastTime = time;
  update(dt);
  draw(time);
  requestAnimationFrame(frame);
}

function pointerPosition(event) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: ((event.clientX - rect.left) / rect.width) * W,
    y: ((event.clientY - rect.top) / rect.height) * H,
  };
}

window.addEventListener("keydown", (event) => {
  keys.add(event.key);
  makeAudio()?.resume();
  if (event.key === " " && state !== "playing") reset();
});
window.addEventListener("keyup", (event) => keys.delete(event.key));
canvas.addEventListener("pointerdown", (event) => {
  pointer.active = true;
  Object.assign(pointer, pointerPosition(event));
  canvas.setPointerCapture(event.pointerId);
  makeAudio()?.resume();
});
canvas.addEventListener("pointermove", (event) => {
  if (pointer.active) Object.assign(pointer, pointerPosition(event));
});
canvas.addEventListener("pointerup", () => {
  pointer.active = false;
});
restartBtn.addEventListener("click", () => {
  makeAudio()?.resume();
  reset();
});

loadLevel()
  .then((data) => {
    level = data;
    reset();
    requestAnimationFrame(frame);
  })
  .catch(() => {
    messageEl.textContent = "Could not load level. Check levels/one.json.";
  });
