const canvas = document.querySelector("#game");
const ctx = canvas.getContext("2d");
const titleEl = document.querySelector("#title");
const keysEl = document.querySelector("#keys");
const keysTotalEl = document.querySelector("#keys-total");
const energyEl = document.querySelector("#energy");
const abilityEl = document.querySelector("#ability");
const phaseEl = document.querySelector("#phase");
const messageEl = document.querySelector("#message");
const restartBtn = document.querySelector("#restart");

const W = 1280;
const H = 720;
const keys = new Set();
const pointer = { active: false, x: W / 2, y: H / 2, worldX: W / 2, worldY: H / 2 };

const CREATIVE_DIRECTOR = {
  qualityBar: "Start from a complete playable slice: expressive world, player action, risk, progress, reward, finale.",
  sportsArena:
    "For soccer/football/monster sports, transform this into a stadium: ball physics, charged shots, keeper phases, crowd bands, scoreboard pulse, goal replay, confetti finish.",
  fantasyMap:
    "For dragons, castles, forests, or quests, transform this into a larger map: route choice, patrols, keys, wind or traps, boss gate, final reveal.",
  builderTool:
    "For simulations or tools, keep the canvas as a live scene and use the HUD/panel for choices, state, result, and next-step payoff.",
};

let audio;
let level;
let world;
let player;
let cores;
let particles;
let trails;
let ripples;
let drones;
let props;
let state;
let lastTime = 0;
let shake = 0;
let camera;
let phase = 1;

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function lerp(a, b, t) {
  return a + (b - a) * t;
}

function circleRectHit(circle, rect) {
  const x = clamp(circle.x, rect.x, rect.x + rect.w);
  const y = clamp(circle.y, rect.y, rect.y + rect.h);
  const dx = circle.x - x;
  const dy = circle.y - y;
  return dx * dx + dy * dy < circle.r * circle.r;
}

function makeAudio() {
  if (audio) return audio;
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) return null;
  audio = new AudioContextClass();
  return audio;
}

function blip(freq, duration = 0.08, gain = 0.04, type = "triangle") {
  const ac = makeAudio();
  if (!ac) return;
  if (ac.state === "suspended") ac.resume();
  const osc = ac.createOscillator();
  const amp = ac.createGain();
  osc.frequency.value = freq;
  osc.type = type;
  amp.gain.setValueAtTime(gain, ac.currentTime);
  amp.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + duration);
  osc.connect(amp).connect(ac.destination);
  osc.start();
  osc.stop(ac.currentTime + duration);
}

async function loadLevel() {
  const response = await fetch("./levels/one.json");
  if (!response.ok) throw new Error("level load failed");
  return response.json();
}

function burst(x, y, color, count = 16, power = 1) {
  for (let i = 0; i < count; i += 1) {
    const angle = Math.random() * Math.PI * 2;
    const speed = (70 + Math.random() * 260) * power;
    particles.push({
      x,
      y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      life: 0.45 + Math.random() * 0.55,
      max: 0.9,
      size: 2.4 + Math.random() * 4.8,
      color,
    });
  }
}

function addRipple(x, y, color, max = 130) {
  ripples.push({ x, y, color, life: 0.62, maxLife: 0.62, radius: 16, max });
}

function reset() {
  world = {
    w: level.world?.w || W,
    h: level.world?.h || H,
    theme: level.world?.theme || "neon-map",
  };
  player = {
    x: level.start.x,
    y: level.start.y,
    r: 19,
    vx: 0,
    vy: 0,
    energy: 100,
    dashCooldown: 0,
    combo: 0,
    invulnerable: 0,
    facing: 0,
  };
  cores = level.cores.map((core) => ({ ...core, taken: false, pulse: Math.random() * 9 }));
  drones = level.drones.map((drone) => ({ ...drone, t: Math.random() * 9, x: drone.origin.x, y: drone.origin.y }));
  props = (level.props || []).map((prop) => ({ ...prop, pulse: Math.random() * 10 }));
  camera = { x: 0, y: 0, targetX: 0, targetY: 0, zoom: 1, parallax: 0.18 };
  particles = [];
  trails = [];
  ripples = [];
  state = "playing";
  phase = 1;
  shake = 0;
  updateHud();
  messageEl.textContent = level.brief;
}

function updateHud() {
  const taken = cores.filter((core) => core.taken).length;
  titleEl.textContent = level.title;
  keysEl.textContent = String(taken);
  keysTotalEl.textContent = String(cores.length);
  energyEl.textContent = String(Math.max(0, Math.round(player.energy)));
  abilityEl.textContent = player.dashCooldown <= 0 ? "Ready" : `${Math.ceil(player.dashCooldown * 10) / 10}s`;
  phaseEl.textContent = String(phase);
}

function screenToWorld(x, y) {
  return { x: x + camera.x, y: y + camera.y };
}

function inputVector() {
  let x = 0;
  let y = 0;
  if (keys.has("ArrowLeft") || keys.has("a") || keys.has("A")) x -= 1;
  if (keys.has("ArrowRight") || keys.has("d") || keys.has("D")) x += 1;
  if (keys.has("ArrowUp") || keys.has("w") || keys.has("W")) y -= 1;
  if (keys.has("ArrowDown") || keys.has("s") || keys.has("S")) y += 1;
  if (pointer.active) {
    x += clamp((pointer.worldX - player.x) / 160, -1, 1);
    y += clamp((pointer.worldY - player.y) / 160, -1, 1);
  }
  const mag = Math.hypot(x, y) || 1;
  return { x: x / mag, y: y / mag, active: Math.abs(x) + Math.abs(y) > 0 };
}

function tryDash(direction = inputVector()) {
  if (state !== "playing" || player.dashCooldown > 0 || player.energy < 18) return;
  const dx = direction.active ? direction.x : Math.cos(player.facing);
  const dy = direction.active ? direction.y : Math.sin(player.facing);
  player.vx += dx * 720;
  player.vy += dy * 720;
  player.energy -= 16;
  player.dashCooldown = 0.85;
  player.invulnerable = 0.18;
  player.combo += 1;
  shake = 10;
  burst(player.x, player.y, "#43d9ff", 18, 0.72);
  addRipple(player.x, player.y, "#43d9ff", 110);
  blip(420 + player.combo * 28, 0.08, 0.035, "square");
}

function movePlayer(dt) {
  const input = inputVector();
  const accel = input.active ? 1080 : 0;
  if (input.active) player.facing = Math.atan2(input.y, input.x);
  player.vx += input.x * accel * dt;
  player.vy += input.y * accel * dt;
  player.vx *= Math.pow(0.08, dt);
  player.vy *= Math.pow(0.08, dt);

  const next = {
    x: clamp(player.x + player.vx * dt, player.r, world.w - player.r),
    y: clamp(player.y + player.vy * dt, player.r, world.h - player.r),
    r: player.r,
  };

  for (const wall of level.walls) {
    if (circleRectHit(next, wall)) {
      next.x = player.x;
      next.y = player.y;
      player.vx *= -0.28;
      player.vy *= -0.28;
      player.combo = 0;
      shake = 8;
      addRipple(player.x, player.y, "#ff4fb8", 78);
    }
  }
  player.x = next.x;
  player.y = next.y;
  trails.push({ x: player.x, y: player.y, life: 0.25, max: 0.25, color: player.invulnerable > 0 ? "#ffe66d" : "#43d9ff" });
}

function updateCamera() {
  camera.targetX = clamp(player.x - W * 0.5, 0, Math.max(0, world.w - W));
  camera.targetY = clamp(player.y - H * 0.5, 0, Math.max(0, world.h - H));
  camera.x = lerp(camera.x, camera.targetX, 0.09);
  camera.y = lerp(camera.y, camera.targetY, 0.09);
}

function update(dt) {
  particles.forEach((p) => {
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vx *= Math.pow(0.04, dt);
    p.vy *= Math.pow(0.04, dt);
    p.life -= dt;
  });
  particles = particles.filter((p) => p.life > 0);
  trails.forEach((p) => (p.life -= dt));
  trails = trails.filter((p) => p.life > 0);
  ripples.forEach((r) => {
    r.life -= dt;
    r.radius = lerp(r.radius, r.max, 0.12);
  });
  ripples = ripples.filter((r) => r.life > 0);

  if (state !== "playing") return;

  player.dashCooldown = Math.max(0, player.dashCooldown - dt);
  player.invulnerable = Math.max(0, player.invulnerable - dt);
  player.energy = clamp(player.energy + 8 * dt, 0, 100);
  movePlayer(dt);
  updateCamera();
  shake = Math.max(0, shake - 34 * dt);

  const takenCount = cores.filter((c) => c.taken).length;
  phase = 1 + takenCount;

  for (const core of cores) {
    core.pulse += dt;
    if (!core.taken && Math.hypot(player.x - core.x, player.y - core.y) < player.r + 20) {
      core.taken = true;
      player.combo += 2;
      burst(core.x, core.y, core.color || "#ffe66d", 28, 1.05);
      addRipple(core.x, core.y, core.color || "#ffe66d", 150);
      blip(620 + cores.filter((c) => c.taken).length * 90, 0.12, 0.055);
      messageEl.textContent = core.message || "Core captured. The route is changing.";
    }
  }

  for (const drone of drones) {
    drone.t += dt * (1 + takenCount * 0.12);
    const dx = Math.cos(drone.t * drone.speed) * drone.range;
    const dy = Math.sin(drone.t * drone.speed * 0.74) * drone.range * 0.58;
    drone.x = drone.origin.x + dx;
    drone.y = drone.origin.y + dy;
    if (Math.hypot(player.x - drone.x, player.y - drone.y) < player.r + drone.r && player.invulnerable <= 0) {
      player.energy -= (34 + takenCount * 7) * dt;
      player.combo = 0;
      shake = 14;
      if (Math.random() < 0.45) burst(player.x, player.y, "#ff4fb8", 3, 0.64);
      if (player.energy <= 0) {
        state = "lost";
        messageEl.textContent = level.failText || "Energy empty. Change the route and try again.";
        burst(player.x, player.y, "#ff4fb8", 46, 1.2);
        addRipple(player.x, player.y, "#ff4fb8", 190);
        blip(160, 0.22, 0.07, "sawtooth");
      }
    }
  }

  const allCores = cores.every((core) => core.taken);
  if (allCores && Math.hypot(player.x - level.gate.x, player.y - level.gate.y) < player.r + level.gate.r) {
    state = "won";
    messageEl.textContent = level.winText || "Gate online. Add a new level, boss, or final scene next.";
    burst(level.gate.x, level.gate.y, "#43d9ff", 90, 1.3);
    burst(level.gate.x, level.gate.y, "#ffe66d", 54, 0.9);
    addRipple(level.gate.x, level.gate.y, "#43d9ff", 260);
    blip(880, 0.3, 0.08);
  }

  updateHud();
}

function drawBackground(time) {
  const gradient = ctx.createLinearGradient(0, 0, W, H);
  gradient.addColorStop(0, "#07101d");
  gradient.addColorStop(0.5, "#11193a");
  gradient.addColorStop(1, "#090b14");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, W, H);

  const nebula = ctx.createRadialGradient(W * 0.68 - camera.x * 0.08, H * 0.22 - camera.y * 0.08, 0, W * 0.68, H * 0.22, 520);
  nebula.addColorStop(0, "rgba(255,79,184,0.24)");
  nebula.addColorStop(0.42, "rgba(67,217,255,0.10)");
  nebula.addColorStop(1, "rgba(67,217,255,0)");
  ctx.fillStyle = nebula;
  ctx.fillRect(0, 0, W, H);

  ctx.save();
  ctx.translate((-camera.x * 0.18) % 96, (-camera.y * 0.1) % 96);
  ctx.globalAlpha = 0.18;
  ctx.strokeStyle = "#43d9ff";
  ctx.lineWidth = 1;
  for (let x = -160; x < W + 220; x += 64) {
    ctx.beginPath();
    ctx.moveTo(x + Math.sin(time * 0.001 + x) * 12, -140);
    ctx.lineTo(x - 230, H + 160);
    ctx.stroke();
  }
  for (let y = -160; y < H + 160; y += 80) {
    ctx.beginPath();
    ctx.moveTo(-160, y);
    ctx.lineTo(W + 160, y + Math.sin(time * 0.0008 + y) * 16);
    ctx.stroke();
  }
  ctx.restore();

  ctx.save();
  ctx.globalAlpha = 0.38;
  for (let i = 0; i < 120; i += 1) {
    const x = (i * 97 + Math.sin(time * 0.0002 + i) * 18 - camera.x * (0.06 + (i % 5) * 0.012)) % W;
    const y = (i * 53 + Math.cos(time * 0.0003 + i) * 12 - camera.y * (0.04 + (i % 7) * 0.01)) % H;
    ctx.fillStyle = i % 5 === 0 ? "#ffe66d" : "#f6f2ff";
    ctx.fillRect((x + W) % W, (y + H) % H, i % 7 === 0 ? 3 : 1.5, i % 7 === 0 ? 3 : 1.5);
  }
  ctx.restore();
}

function drawGlowCircle(x, y, r, color, alpha = 1) {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r * 3.2);
  g.addColorStop(0, color);
  g.addColorStop(0.32, `${color}99`);
  g.addColorStop(1, `${color}00`);
  ctx.globalAlpha = alpha;
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y, r * 3.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;
}

function drawWorldFloor(time) {
  ctx.save();
  const bg = ctx.createLinearGradient(0, 0, world.w, world.h);
  bg.addColorStop(0, "rgba(67,217,255,0.07)");
  bg.addColorStop(0.5, "rgba(255,79,184,0.045)");
  bg.addColorStop(1, "rgba(255,230,109,0.055)");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, world.w, world.h);

  ctx.globalAlpha = 0.16;
  ctx.strokeStyle = "#f6f2ff";
  ctx.lineWidth = 1;
  for (let x = 0; x <= world.w; x += 96) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x + Math.sin(time * 0.0007 + x) * 22, world.h);
    ctx.stroke();
  }
  for (let y = 0; y <= world.h; y += 96) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(world.w, y + Math.cos(time * 0.0005 + y) * 18);
    ctx.stroke();
  }
  ctx.restore();
}

function drawWall(wall) {
  const g = ctx.createLinearGradient(wall.x, wall.y, wall.x + wall.w, wall.y + wall.h);
  g.addColorStop(0, "rgba(255,255,255,0.16)");
  g.addColorStop(0.5, "rgba(67,217,255,0.09)");
  g.addColorStop(1, "rgba(255,79,184,0.13)");
  ctx.fillStyle = g;
  ctx.shadowColor = "rgba(67,217,255,0.35)";
  ctx.shadowBlur = 16;
  ctx.fillRect(wall.x, wall.y, wall.w, wall.h);
  ctx.shadowBlur = 0;
  ctx.strokeStyle = "rgba(255,255,255,0.36)";
  ctx.lineWidth = 2;
  ctx.strokeRect(wall.x + 1, wall.y + 1, wall.w - 2, wall.h - 2);
}

function drawProp(prop, time) {
  ctx.save();
  ctx.translate(prop.x, prop.y);
  ctx.rotate((prop.spin || 0) * time * 0.001 + prop.pulse * 0.08);
  ctx.shadowColor = prop.color || "#43d9ff";
  ctx.shadowBlur = 24;
  const shape = new Path2D();
  const size = prop.size || 34;
  shape.moveTo(0, -size);
  shape.bezierCurveTo(size * 0.62, -size * 0.28, size * 0.44, size * 0.52, 0, size);
  shape.bezierCurveTo(-size * 0.44, size * 0.52, -size * 0.62, -size * 0.28, 0, -size);
  const g = ctx.createLinearGradient(-size, -size, size, size);
  g.addColorStop(0, prop.color || "#43d9ff");
  g.addColorStop(1, "#f6f2ff");
  ctx.fillStyle = g;
  ctx.fill(shape);
  ctx.shadowBlur = 0;
  ctx.globalAlpha = 0.52;
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 2;
  ctx.stroke(shape);
  ctx.restore();
}

function drawCore(core) {
  const pulse = Math.sin(core.pulse * 5) * 4;
  const color = core.color || "#ffe66d";
  drawGlowCircle(core.x, core.y, 14 + pulse, color, 0.8);
  ctx.save();
  ctx.translate(core.x, core.y);
  ctx.rotate(core.pulse);
  ctx.shadowColor = color;
  ctx.shadowBlur = 22;
  ctx.fillStyle = color;
  for (let i = 0; i < 7; i += 1) {
    ctx.rotate(Math.PI / 3.5);
    ctx.fillRect(-3, -20 - pulse * 0.2, 6, 22);
  }
  ctx.beginPath();
  ctx.arc(0, 0, 10 + pulse * 0.3, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawDrone(drone) {
  drawGlowCircle(drone.x, drone.y, drone.r, "#ff4fb8", 0.55);
  ctx.save();
  ctx.translate(drone.x, drone.y);
  ctx.rotate(Math.sin(drone.t * 2) * 0.2 + (drone.t % 6) * 0.08);
  ctx.shadowColor = "#ff4fb8";
  ctx.shadowBlur = 20;
  const shell = new Path2D();
  shell.moveTo(-drone.r * 1.15, 0);
  shell.quadraticCurveTo(0, -drone.r * 1.32, drone.r * 1.15, 0);
  shell.quadraticCurveTo(0, drone.r * 1.05, -drone.r * 1.15, 0);
  ctx.fillStyle = "#ff4fb8";
  ctx.fill(shell);
  ctx.shadowBlur = 0;
  ctx.fillStyle = "#11172a";
  ctx.beginPath();
  ctx.ellipse(0, -3, drone.r * 0.42, drone.r * 0.3, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#ffe66d";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(-drone.r * 1.4, drone.r * 0.42);
  ctx.lineTo(drone.r * 1.4, drone.r * 0.42);
  ctx.stroke();
  ctx.restore();
}

function drawHero() {
  drawGlowCircle(player.x, player.y, player.r, player.invulnerable > 0 ? "#ffe66d" : "#43d9ff", 0.55);
  ctx.save();
  ctx.translate(player.x, player.y);
  ctx.rotate(player.facing + Math.sin(performance.now() * 0.008) * 0.04);
  ctx.shadowColor = player.invulnerable > 0 ? "#ffe66d" : "#43d9ff";
  ctx.shadowBlur = 24;
  const body = new Path2D();
  body.moveTo(player.r * 1.32, 0);
  body.bezierCurveTo(player.r * 0.38, -player.r * 1.02, -player.r * 0.95, -player.r * 0.92, -player.r * 1.26, 0);
  body.bezierCurveTo(-player.r * 0.95, player.r * 0.92, player.r * 0.38, player.r * 1.02, player.r * 1.32, 0);
  const suit = ctx.createLinearGradient(-player.r, -player.r, player.r, player.r);
  suit.addColorStop(0, "#f6f2ff");
  suit.addColorStop(0.52, "#43d9ff");
  suit.addColorStop(1, "#a78bfa");
  ctx.fillStyle = suit;
  ctx.fill(body);
  ctx.shadowBlur = 0;
  ctx.fillStyle = "#08111f";
  ctx.beginPath();
  ctx.ellipse(player.r * 0.18, -2, player.r * 0.45, player.r * 0.28, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = player.invulnerable > 0 ? "#ffe66d" : "#43d9ff";
  ctx.lineWidth = 4;
  ctx.stroke(body);
  ctx.restore();
}

function drawGate(time) {
  const open = cores.every((core) => core.taken);
  const color = open ? "#43d9ff" : "#62708f";
  const pulse = open ? Math.sin(time * 0.006) * 7 : Math.sin(time * 0.002) * 2;
  drawGlowCircle(level.gate.x, level.gate.y, level.gate.r + pulse, color, open ? 0.9 : 0.35);
  ctx.save();
  ctx.translate(level.gate.x, level.gate.y);
  ctx.rotate(time * 0.0012);
  ctx.strokeStyle = color;
  ctx.lineWidth = 8;
  for (let i = 0; i < 3; i += 1) {
    ctx.rotate(Math.PI / 3);
    ctx.beginPath();
    ctx.ellipse(0, 0, level.gate.r + pulse + i * 12, level.gate.r * 0.56 + pulse, 0, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
}

function drawMinimap() {
  const scaleX = 152 / world.w;
  const scaleY = 86 / world.h;
  ctx.save();
  ctx.translate(W - 192, H - 122);
  ctx.globalAlpha = 0.86;
  ctx.fillStyle = "rgba(7,9,18,0.74)";
  ctx.fillRect(0, 0, 152, 86);
  ctx.strokeStyle = "rgba(255,255,255,0.28)";
  ctx.strokeRect(0, 0, 152, 86);
  ctx.strokeStyle = "rgba(67,217,255,0.5)";
  ctx.strokeRect(camera.x * scaleX, camera.y * scaleY, W * scaleX, H * scaleY);
  ctx.fillStyle = "#43d9ff";
  ctx.fillRect(player.x * scaleX - 3, player.y * scaleY - 3, 6, 6);
  ctx.fillStyle = "#ffe66d";
  cores.filter((core) => !core.taken).forEach((core) => ctx.fillRect(core.x * scaleX - 2, core.y * scaleY - 2, 4, 4));
  ctx.fillStyle = "#ff4fb8";
  drones.forEach((drone) => ctx.fillRect(drone.x * scaleX - 2, drone.y * scaleY - 2, 4, 4));
  ctx.restore();
}

function draw(time) {
  ctx.save();
  ctx.clearRect(0, 0, W, H);
  if (shake) ctx.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake);
  drawBackground(time);

  ctx.save();
  ctx.translate(-camera.x, -camera.y);
  drawWorldFloor(time);
  for (const prop of props) drawProp(prop, time);
  for (const wall of level.walls) drawWall(wall);
  drawGate(time);

  for (const core of cores) {
    if (!core.taken) drawCore(core);
  }
  for (const drone of drones) drawDrone(drone);

  for (const r of ripples) {
    ctx.globalAlpha = clamp(r.life / r.maxLife, 0, 1);
    ctx.strokeStyle = r.color;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(r.x, r.y, r.radius, 0, Math.PI * 2);
    ctx.stroke();
  }
  for (const p of trails) {
    ctx.globalAlpha = clamp(p.life / p.max, 0, 1) * 0.55;
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, 12 * clamp(p.life / p.max, 0, 1), 0, Math.PI * 2);
    ctx.fill();
  }
  for (const p of particles) {
    ctx.globalAlpha = clamp(p.life / p.max, 0, 1);
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
  drawHero();
  ctx.restore();

  drawMinimap();

  if (state !== "playing") {
    ctx.fillStyle = "rgba(7, 9, 18, 0.66)";
    ctx.fillRect(0, 0, W, H);
    ctx.textAlign = "center";
    ctx.fillStyle = state === "won" ? "#43d9ff" : "#ff4fb8";
    ctx.font = "900 76px system-ui";
    ctx.fillText(state === "won" ? level.finalTitle || "GATE ONLINE" : "TRY AGAIN", W / 2, H / 2);
    ctx.fillStyle = "#f6f2ff";
    ctx.font = "600 24px system-ui";
    ctx.fillText("Press Restart or Space", W / 2, H / 2 + 48);
  }
  ctx.restore();
}

function frame(time) {
  const dt = Math.min(0.033, (time - lastTime) / 1000 || 0.016);
  lastTime = time;
  update(dt);
  draw(time);
  requestAnimationFrame(frame);
}

function pointerPosition(event) {
  const rect = canvas.getBoundingClientRect();
  const x = ((event.clientX - rect.left) / rect.width) * W;
  const y = ((event.clientY - rect.top) / rect.height) * H;
  const worldPoint = screenToWorld(x, y);
  return { x, y, worldX: worldPoint.x, worldY: worldPoint.y };
}

window.addEventListener("keydown", (event) => {
  keys.add(event.key);
  makeAudio()?.resume();
  if ((event.key === " " || event.key === "Shift") && state === "playing") {
    event.preventDefault();
    tryDash();
  } else if ((event.key === " " || event.key === "Enter") && state !== "playing") {
    reset();
  }
});
window.addEventListener("keyup", (event) => keys.delete(event.key));
canvas.addEventListener("pointerdown", (event) => {
  pointer.active = true;
  Object.assign(pointer, pointerPosition(event));
  canvas.setPointerCapture(event.pointerId);
  makeAudio()?.resume();
  tryDash({ x: clamp((pointer.worldX - player.x) / 160, -1, 1), y: clamp((pointer.worldY - player.y) / 160, -1, 1), active: true });
});
canvas.addEventListener("pointermove", (event) => {
  Object.assign(pointer, pointerPosition(event));
});
canvas.addEventListener("pointerup", () => {
  pointer.active = false;
});
restartBtn.addEventListener("click", () => {
  makeAudio()?.resume();
  reset();
});

loadLevel()
  .then((data) => {
    level = data;
    reset();
    requestAnimationFrame(frame);
  })
  .catch(() => {
    messageEl.textContent = "Could not load level. Check levels/one.json.";
  });
