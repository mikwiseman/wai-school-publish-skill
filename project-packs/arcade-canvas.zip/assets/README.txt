Use this folder for local game art, sprites, audio, fonts, generated textures, and data notes.
Keep every path relative, for example ./assets/player.png.
If the game theme needs richer characters, create a small sprite sheet or generated image here instead of drawing only circles or squares.
