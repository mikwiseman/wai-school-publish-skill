Use this folder for local game art, sprites, audio, fonts, and generated images.
Keep every path relative, for example ./assets/player.png.
